#!/bin/bash

echo "source $(pwd)/rc.sh $(pwd)"
