-- Danis cool config

lspconfig.hls.setup {
	on_attach = on_attach,
	on_init = on_init,
	capabilities = capabilities,
	filetypes = { 'haskell', 'lhaskell', 'cabal' },
}

lspconfig.clangd.setup {
    cmd = { "clangd", "--header-insertion=never", "--extra-arg=-I" .. vim.fn.getcwd() .. "/include" },
    filetypes = { "c", "cpp", "objc", "objcpp" },
	root_dir = function(fname)
        return lspconfig.util.root_pattern("compile_commands.json", ".git")(fname) or lspconfig.util.path.dirname(fname)
    end,
    capabilities = capabilities,
    on_attach = on_attach,
}

lspconfig.asm_lsp.setup {
  cmd = { "asm-lsp" },
  filetypes = { "asm", "nasm" }, -- Ensure it works with Intel syntax files
  root_dir = lspconfig.util.root_pattern(".git", "."),
  settings = {
    asm = {
      dialect = "intel" -- Force Intel x86_64 syntax
    }
  }
}

lspconfig.checkmake.setup({
  cmd = { "checkmake" },
  filetypes = { "make" },
  root_dir = lspconfig.util.root_pattern("Makefile"),
})

