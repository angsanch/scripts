input_file="./nvim_lsp.lua"
output_file="test"
target_line="-- Danis cool config"
awk -v target="$target_line" '{
  if ($0 == target) exit;  # Exit when the target line is found
  print;                  # Print lines before the target
}' "$output_file" | cat - "$input_file" > temp.txt
rm -f "$output_file"
mv temp.txt "$output_file"
