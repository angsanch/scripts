#!/usr/bin/env bash

mkdir -p ~/.config/flameshot
cp data/flameshot.ini ~/.config/flameshot/flameshot.ini
